package com.example.kanofood.ui.user;

public class UserViewModel {
}
