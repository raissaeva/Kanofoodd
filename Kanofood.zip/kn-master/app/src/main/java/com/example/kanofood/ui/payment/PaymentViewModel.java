package com.example.kanofood.ui.payment;

public class PaymentViewModel {
}
