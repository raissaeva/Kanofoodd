package com.example.kanofood.ui.order;

public class OrderFragment {
}
