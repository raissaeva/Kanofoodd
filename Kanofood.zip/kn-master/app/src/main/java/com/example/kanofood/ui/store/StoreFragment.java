package com.example.kanofood.ui.store;

public class StoreFragment {
}
